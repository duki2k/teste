"""Atlas Bot v6 — config.py

⚠️ Ajuste os IDs para o seu servidor Discord.

- IDs de canais e cargos são inteiros.
- RSS feeds são uma lista de tuplas: ("Fonte", "URL").

Dica: no Discord, ative o modo desenvolvedor → clique direito no canal/cargo → Copy ID.
"""

# ─────────────────────────────
# Canais (Discord)
# ─────────────────────────────
CANAL_LOGS = 0            # canal privado de logs
CANAL_NEWS_CRIPTO = 0     # canal de newsletter

# ─────────────────────────────
# Telegram (opcional)
# ─────────────────────────────
TELEGRAM_ENABLED = False
TELEGRAM_SEND_NEWS = True

# ─────────────────────────────
# Links / branding
# ─────────────────────────────
DISCORD_INVITE_LINK = "https://discord.gg/COLE_SEU_INVITE"

# ─────────────────────────────
# Newsletter
# ─────────────────────────────
NEWS_EVERY_MINUTES = 30
NEWS_MAX_ITEMS_EACH = 6

# Lista base de RSS em inglês (ajuste à vontade)
NEWS_RSS_FEEDS_EN = [
    ("CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/"),
    ("Cointelegraph", "https://cointelegraph.com/rss"),
    ("Decrypt", "https://decrypt.co/feed"),
    ("CryptoSlate", "https://cryptoslate.com/feed/"),
    ("Blockworks", "https://blockworks.co/feed"),
]
