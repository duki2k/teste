# Atlas Bot v6 (Skeleton)

Este repositório é o **ponto de partida** do Atlas Bot v6.

✅ Já inclui:
- Slash commands: `/status`, `/resync`, `/debug`, `/force_all`
- Newsroom PT/EN (editorial PT sem API)
- Envio no Discord + (opcional) Telegram
- Logs limpos com níveis (`LOG_LEVEL`)

## 1) Como rodar local

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate

pip install -r requirements.txt
cp .env.example .env
# edite .env

# rode (importante: PYTHONPATH=src)
PYTHONPATH=src python -m atlas.main
```

## 2) Como subir no Railway

- Conecte o GitHub repo no Railway
- Configure as **Variables** (veja `.env.example`)
- Start command recomendado:

```bash
PYTHONPATH=src python -m atlas.main
```

## 3) Configuração do Discord

1. Crie o App/Bot e pegue o `DISCORD_TOKEN`.
2. Faça invite do bot com scopes:
   - `bot`
   - `applications.commands`
3. Ajuste `config.py`:
   - `CANAL_NEWS_CRIPTO` (onde enviar newsletter)
   - `CANAL_LOGS` (logs privados)
   - `NEWS_RSS_FEEDS_EN` (feeds)

## 4) Teste rápido

- Rode `/resync` (Admin)
- Rode `/force_all` para mandar uma newsletter de teste

---

Próximas etapas do v6: Mentor Binance + Signals + Autotrade master.
